im = double(rgb2gray(imread('image/img1.bmp')));

feat = bsd_feature(im);