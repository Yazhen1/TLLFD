function [ feat ] = TLLFD_feature( imdist )

 
% inputs:
% imdist - the distorted image (grayscale image, double type, 0~255)

% outputs:
% 44-d features. 
% "Two Low-level Feature Distributions based No Reference Image Quality
% Assessment" Hao Fu, Guojun Liua*, Xiaoqin Yang, Lili Wei, Lixia Yang
%[2022.5.7]

scalenum = 2;
K1 = 0.01;
C1 = (K1*255)^2;


window = fspecial('gaussian',7,7/6);
window = window/sum(sum(window));
feat = [];

%% prewitt operator %%%%%
dx = [1 0 -1; 1 0 -1; 1 0 -1]/3;
dy = dx';

for itr_scale = 1:scalenum
    
    mu            = filter2(window, imdist, 'same');
    mu_sq         = mu.*mu;
    sigma         = sqrt(abs(filter2(window, imdist.*imdist, 'same') - mu_sq));
    structdis     = (imdist-mu)./(sigma+C1);  %��һ��ͼ��
    
    
    R = 1; P = 8;
    lbp_type = { 'ri' 'u2' 'riu2' };
    y = 3;
    mtype = lbp_type{y};
    MAPPING = getmapping( P, mtype );
    [CLBP_SH,CLBP_MH]=clbp(structdis,1,8,MAPPING,'x'); %û��ȨLBPmapͼ
    %%% visibility weighted LBP %%%%%
    
    wLBPHist = [];
    wintesity = structdis(2:end-1, 2:end-1);
    wintensity = abs(wintesity);
    for k = 1:max(CLBP_SH(:))+1
        idx = find(CLBP_SH == k-1);
        kval = sum(wintensity(idx));
        wLBPHist = [wLBPHist kval];%%%%weighted LBP %%%%%
    end
    wLBPHist = wLBPHist/sum(wLBPHist);
    feat = [feat wLBPHist];
    
   %%% visibility weighted LBP %%%%%
   
   
    wLBPHist1 = [];
    wintesity1 = structdis(2:end-1, 2:end-1);
    wintensity1 = abs(wintesity1);
    for k = 1:max(CLBP_MH(:))+1
        idx1 = find(CLBP_MH == k-1);
        kval1 = sum(wintensity1(idx1));
        wLBPHist1 = [wLBPHist1 kval1];
    end
    wLBPHist1 = wLBPHist1/sum(wLBPHist1);
     
    feat = [feat wLBPHist1];  
 
    
    %%%%%%%%%% Gradient magnitud map %%%%%%%%%%%%
    IxY1 = conv2(structdis, dx, 'same');
    IyY1 = conv2(structdis, dy, 'same');
    gradientMap = sqrt(IxY1.^2 + IyY1.^2);
    gmvals = gradientMap(:);
    gmvals(gmvals==0) = [];
    wblpara = wblfit(gmvals); %weibull �ֲ�
    feat = [feat wblpara];
    
    imdist = imresize(imdist, 0.5); %��Сһ��ߴ磬2���߶�
end

end

